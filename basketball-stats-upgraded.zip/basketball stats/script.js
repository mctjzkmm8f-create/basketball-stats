// Upgraded Basketball Stats
const form=document.getElementById('statsForm');
const tableBody=document.getElementById('statsTableBody');
const ids=['gamesCount','avgPoints','avgRebounds','avgAssists','avgBlocks'];
const [gamesCountEl,avgPointsEl,avgReboundsEl,avgAssistsEl,avgBlocksEl]=ids.map(id=>document.getElementById(id));
let stats=JSON.parse(localStorage.getItem('basketballStats'))||[];
let chart,editIndex=-1;
function save(){localStorage.setItem('basketballStats',JSON.stringify(stats));}
function renderSummary(){
 let g=stats.length;gamesCountEl.textContent=g;
 if(!g){avgPointsEl.textContent=avgReboundsEl.textContent=avgAssistsEl.textContent=avgBlocksEl.textContent=0;return;}
 const avg=k=>(stats.reduce((s,x)=>s+Number(x[k]),0)/g).toFixed(1);
 avgPointsEl.textContent=avg('points');
 avgReboundsEl.textContent=avg('rebounds');
 avgAssistsEl.textContent=avg('assists');
 avgBlocksEl.textContent=avg('blocks');
}
function renderChart(){
 const ctx=document.getElementById('pointsChart').getContext('2d');
 if(chart)chart.destroy();
 chart=new Chart(ctx,{type:'line',data:{labels:stats.map(x=>x.date),datasets:[
 {label:'득점',data:stats.map(x=>x.points)},
 {label:'리바운드',data:stats.map(x=>x.rebounds)},
 {label:'어시스트',data:stats.map(x=>x.assists)},
 {label:'블락',data:stats.map(x=>x.blocks)}
 ]}});
}
window.editGame=i=>{
 editIndex=i;
 const g=stats[i];
 date.value=g.date;opponent.value=g.opponent;points.value=g.points;rebounds.value=g.rebounds;assists.value=g.assists;blocks.value=g.blocks;
}
window.deleteGame=i=>{
 if(confirm('삭제할까요?')){
 stats.splice(i,1);save();renderAll();
 }
}
function renderTable(){
 tableBody.innerHTML='';
 stats.forEach((g,i)=>{
 tableBody.innerHTML+=`<tr><td>${i+1}</td><td>${g.date}</td><td>${g.opponent}</td><td>${g.points}</td><td>${g.rebounds}</td><td>${g.assists}</td><td>${g.blocks}</td><td><button class="editBtn" onclick="editGame(${i})">수정</button></td><td><button class="deleteBtn" onclick="deleteGame(${i})">삭제</button></td></tr>`;
 });
}
function renderAll(){renderTable();renderSummary();renderChart();}
form.addEventListener('submit',e=>{
 e.preventDefault();
 const g={date:date.value,opponent:opponent.value,points:+points.value,rebounds:+rebounds.value,assists:+assists.value,blocks:+blocks.value};
 if(editIndex==-1)stats.push(g); else {stats[editIndex]=g;editIndex=-1;}
 save();form.reset();renderAll();
});
renderAll();
